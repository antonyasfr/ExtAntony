(function () {
  'use strict';

  var $ = function (id) { return document.getElementById(id); };

  var state = {
    wallpaper: null,
    palette: null,
    settings: Object.assign({}, WPStore.DEFAULT_SETTINGS),
    theme: WPStore.DEFAULT_THEME
  };

  var toastTimer = null;
  function toast(message) {
    var el = $('toast');
    el.textContent = message;
    el.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { el.hidden = true; }, 4500);
  }

  function effectiveIndex() {
    var c = state.settings.accentChoice;
    return (c === 'auto' || !state.palette.swatches[c]) ? state.palette.accentIndex : c;
  }

  function persistSettings() {
    return WPStore.save({ settings: state.settings, theme: state.theme }).catch(function () {
      toast('Não consegui salvar a mudança. Tente de novo.');
    });
  }

  /* ---------- desenho da página ---------- */

  function renderRibbon() {
    var ribbon = $('ribbon');
    ribbon.replaceChildren();
    var current = effectiveIndex();

    state.palette.swatches.forEach(function (sw, i) {
      var btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'tone';
      btn.setAttribute('role', 'radio');
      btn.setAttribute('aria-checked', String(i === current));
      btn.setAttribute('aria-label', 'Usar ' + sw.hex + ' como cor de destaque');
      btn.title = sw.hex + ' ocupa ' + Math.max(1, Math.round(sw.share * 100)) + '% da imagem';
      btn.style.background = sw.hex;
      btn.style.color = WPPalette.readableOn(WPPalette.fromHex(sw.hex));
      // Largura proporcional à presença da cor na imagem (com um mínimo para dar para clicar).
      btn.style.flexGrow = String(Math.max(sw.share, 0.08) * 100);

      var label = document.createElement('span');
      label.textContent = sw.hex;
      btn.appendChild(label);

      btn.addEventListener('click', function () { choose(i); });
      ribbon.appendChild(btn);
    });
  }

  function render() {
    var hasWallpaper = !!(state.wallpaper && state.palette);

    WPStore.applyTheme(state.theme, state.theme.scheme, state.palette);

    var shot = $('shot');
    shot.style.backgroundImage = hasWallpaper ? 'url("' + state.wallpaper + '")' : '';
    shot.classList.toggle('has', hasWallpaper);
    shot.title = hasWallpaper ? 'Clique para trocar a imagem' : '';
    $('shotEmpty').hidden = hasWallpaper;
    $('ribbon').hidden = !hasWallpaper;
    $('chipFoot').hidden = !hasWallpaper;

    if (hasWallpaper) {
      renderRibbon();
      var idx = effectiveIndex();
      var auto = state.settings.accentChoice === 'auto';
      $('accentNote').textContent = 'Cor de destaque: ' + state.palette.swatches[idx].hex +
        (auto ? ' (automática)' : ' (escolhida por você)');
      $('btnAuto').hidden = auto;
    }

    $('optNewtab').checked = !!state.settings.newtab;
    $('optShortcuts').checked = state.settings.shortcuts !== false;
    $('optSites').checked = !!state.settings.sites;
    $('optScroll').checked = !!state.settings.scrollbars;
    $('optDim').value = String(state.settings.dim);
    $('dimOut').textContent = state.settings.dim + '%';

    $('optTint').value = state.settings.tint;
    $('optTintAmount').value = String(state.settings.tintAmount);
    $('tintOut').textContent = state.settings.tintAmount + '%';
    $('rowTint').hidden = state.settings.tint === 'off';
    updateTintDemo();
  }

  // A prévia mostra a camada de cor na hora, enquanto o controle é movido.
  function updateTintDemo() {
    var s = state.settings;
    var amount = s.tint === 'off' ? 0 : s.tintAmount / 100;
    document.documentElement.style.setProperty('--tint', String(amount));
  }

  function refreshShortcutsNote() {
    WPStore.getShortcuts().then(function (list) {
      var n = list.length;
      var count = n === 0 ? 'Nenhum atalho salvo ainda.' : n + (n === 1 ? ' atalho salvo.' : ' atalhos salvos.');
      $('shortcutsNote').textContent = count + ' A importação lê a pasta da Discagem Rápida nos favoritos do Opera e não repete atalhos que você já tem.';
    });
  }

  /* ---------- ações ---------- */

  function choose(choice) {
    state.settings.accentChoice = choice;
    state.theme = WPPalette.buildTheme(state.palette, choice);
    render();
    persistSettings();
  }

  function useFile(file) {
    if (!file) return Promise.resolve();
    return createImageBitmap(file).then(function (bitmap) {
      var palette, wallpaper;
      try {
        palette = WPPalette.extract(WPPalette.samplePixels(bitmap));
        wallpaper = WPPalette.encodeImage(bitmap);
      } finally {
        if (bitmap.close) bitmap.close();
      }
      if (!palette) throw new Error('imagem vazia');

      state.settings.accentChoice = 'auto';
      var theme = WPPalette.buildTheme(palette, 'auto');

      return WPStore.save({
        wallpaper: wallpaper,
        palette: palette,
        settings: state.settings,
        theme: theme
      }).then(function () {
        state.wallpaper = wallpaper;
        state.palette = palette;
        state.theme = theme;
        render();
        toast('Pronto. Abra uma nova aba para ver o wallpaper.');
      }).catch(function () {
        toast('Não consegui guardar a imagem. Tente uma imagem menor.');
      });
    }, function () {
      toast('Não consegui abrir esse arquivo como imagem. Use um JPG, PNG ou WebP.');
    });
  }

  function removeWallpaper() {
    WPStore.clearWallpaper().then(function () {
      state.wallpaper = null;
      state.palette = null;
      state.theme = WPStore.DEFAULT_THEME;
      state.settings.accentChoice = 'auto';
      WPStore.save({ settings: state.settings });
      render();
      toast('Wallpaper removido. Os sites voltaram às cores originais.');
    });
  }

  /* ---------- eventos ---------- */

  var fileInput = $('file');
  function openPicker() { fileInput.click(); }

  fileInput.addEventListener('change', function () {
    var file = fileInput.files && fileInput.files[0];
    fileInput.value = '';
    useFile(file);
  });

  var shot = $('shot');
  shot.addEventListener('click', openPicker);
  shot.addEventListener('keydown', function (e) {
    if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openPicker(); }
  });
  $('btnChange').addEventListener('click', openPicker);
  $('btnRemove').addEventListener('click', removeWallpaper);
  $('btnAuto').addEventListener('click', function () { choose('auto'); });

  ['dragenter', 'dragover'].forEach(function (name) {
    document.addEventListener(name, function (e) {
      e.preventDefault();
      shot.classList.add('over');
    });
  });
  document.addEventListener('dragleave', function (e) {
    if (e.relatedTarget === null) shot.classList.remove('over');
  });
  document.addEventListener('drop', function (e) {
    e.preventDefault();
    shot.classList.remove('over');
    var file = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
    useFile(file);
  });

  document.addEventListener('paste', function (e) {
    var file = e.clipboardData && e.clipboardData.files && e.clipboardData.files[0];
    if (file) { e.preventDefault(); useFile(file); }
  });

  $('optShortcuts').addEventListener('change', function (e) {
    state.settings.shortcuts = e.target.checked;
    persistSettings();
  });
  $('btnImport').addEventListener('click', function () {
    WPStore.importSpeedDial().then(function (r) {
      if (r.ok && r.added) toast('Trouxe ' + r.added + (r.added === 1 ? ' atalho' : ' atalhos') + ' da Discagem Rápida.');
      else if (r.ok) toast('Não há atalhos novos para trazer.');
      else if (r.reason === 'notfound') toast('Não encontrei a Discagem Rápida nos favoritos do Opera. Adicione seus atalhos na nova aba, com o botão +.');
      else toast('Não consegui ler os favoritos do Opera.');
      refreshShortcutsNote();
    });
  });
  $('optNewtab').addEventListener('change', function (e) {
    state.settings.newtab = e.target.checked;
    persistSettings();
  });
  $('optSites').addEventListener('change', function (e) {
    state.settings.sites = e.target.checked;
    persistSettings();
  });
  $('optScroll').addEventListener('change', function (e) {
    state.settings.scrollbars = e.target.checked;
    persistSettings();
  });
  $('optTint').addEventListener('change', function (e) {
    state.settings.tint = e.target.value;
    $('rowTint').hidden = state.settings.tint === 'off';
    updateTintDemo();
    persistSettings();
  });
  $('optTintAmount').addEventListener('input', function (e) {
    state.settings.tintAmount = Number(e.target.value);
    $('tintOut').textContent = state.settings.tintAmount + '%';
    updateTintDemo();
  });
  $('optTintAmount').addEventListener('change', persistSettings);
  $('optDim').addEventListener('input', function (e) {
    state.settings.dim = Number(e.target.value);
    $('dimOut').textContent = state.settings.dim + '%';
  });
  $('optDim').addEventListener('change', persistSettings);

  /* ---------- início ---------- */

  WPStore.load().then(function (data) {
    state.wallpaper = data.wallpaper;
    state.palette = data.palette;
    state.settings = data.settings;
    state.theme = data.theme;
    render();
    refreshShortcutsNote();
  });
})();
