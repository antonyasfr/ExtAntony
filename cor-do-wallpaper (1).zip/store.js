/*
 * store.js — leitura/gravação das configurações, atalhos e aplicação do tema nas páginas da extensão.
 */
(function (root) {
  'use strict';

  var DEFAULT_SETTINGS = {
    newtab: true,         // abrir a página da extensão no lugar da página inicial do Opera
    shortcuts: true,      // mostrar os atalhos na nova aba
    sites: true,          // colorir os sites
    scrollbars: false,    // colorir barras de rolagem dos sites
    tint: 'google',       // camada de cor sobre a página: 'off', 'google' ou 'all'
    tintAmount: 20,       // intensidade da camada (5 a 40)
    accentChoice: 'auto', // 'auto' ou índice da cor na paleta
    dim: 35               // escurecimento do wallpaper na nova aba (0 a 70)
  };

  var MAX_SHORTCUTS = 60;

  var DEFAULT_THEME = {
    accent: '#8b9bff',
    onAccent: '#0b0d14',
    scheme: 'dark',
    dark: {
      bg: '#0f1115', surface: '#171a21', border: '#262b36',
      text: '#f2f4f8', muted: '#aab0be', accent: '#8b9bff', onAccent: '#0b0d14'
    },
    light: {
      bg: '#f4f5f8', surface: '#fcfcfd', border: '#dcdfe6',
      text: '#14161c', muted: '#5d6370', accent: '#4a5bd9', onAccent: '#ffffff'
    }
  };

  var area = chrome.storage.local;

  function load() {
    return area.get(['wallpaper', 'palette', 'settings', 'theme', 'shortcuts']).then(function (d) {
      return {
        wallpaper: d.wallpaper || null,
        palette: d.palette || null,
        settings: Object.assign({}, DEFAULT_SETTINGS, d.settings || {}),
        theme: d.theme || DEFAULT_THEME,
        shortcuts: Array.isArray(d.shortcuts) ? d.shortcuts : []
      };
    });
  }

  function save(partial) {
    return area.set(partial);
  }

  function clearWallpaper() {
    return area.remove(['wallpaper', 'palette', 'theme']);
  }

  /* ---------- atalhos ---------- */

  function getShortcuts() {
    return area.get(['shortcuts']).then(function (d) {
      return Array.isArray(d.shortcuts) ? d.shortcuts : [];
    });
  }

  function setShortcuts(list) {
    return area.set({ shortcuts: list });
  }

  function uid() {
    if (root.crypto && root.crypto.randomUUID) return root.crypto.randomUUID();
    return String(Date.now()) + Math.random().toString(16).slice(2);
  }

  // Transforma o que a pessoa digitou em um endereço http(s) válido, ou null.
  // "youtube.com" vira https://youtube.com/, "localhost:3000" vira http://localhost:3000/.
  function normalizeUrl(raw) {
    var t = String(raw || '').trim();
    if (!t) return null;
    if (/^localhost(:\d+)?([\/?#]|$)/i.test(t)) t = 'http://' + t;
    else if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(t)) t = 'https://' + t;
    var u;
    try { u = new URL(t); } catch (e) { return null; }
    if (u.protocol !== 'http:' && u.protocol !== 'https:') return null;
    if (u.username || u.password) return null;
    var host = u.hostname;
    if (!host || (host.indexOf('.') === -1 && host !== 'localhost' && host.charAt(0) !== '[')) return null;
    return u.href;
  }

  function hostOf(url) {
    try { return new URL(url).hostname.replace(/^www\./, ''); } catch (e) { return url; }
  }

  function sameAddress(a, b) {
    return String(a).replace(/\/+$/, '').toLowerCase() === String(b).replace(/\/+$/, '').toLowerCase();
  }

  /*
   * Traz os atalhos da Discagem Rápida do Opera. No Opera ela é guardada como uma pasta de
   * favoritos ("Speed Dial" / "Discagem Rápida"), então lemos essa pasta. Não repete os que já existem.
   * Resolve com { ok, reason, added, total }.
   */
  function importSpeedDial() {
    if (!root.chrome || !chrome.bookmarks || !chrome.bookmarks.getTree) {
      return Promise.resolve({ ok: false, reason: 'unsupported' });
    }
    var nameRe = /speed\s*dial|discagem\s*r[aá]pida/i;

    return chrome.bookmarks.getTree().then(function (tree) {
      var folder = null;
      (function find(nodes) {
        nodes.forEach(function (n) {
          if (folder) return;
          if (!n.url && n.title && nameRe.test(n.title)) { folder = n; return; }
          if (n.children) find(n.children);
        });
      })(tree);
      if (!folder) return { ok: false, reason: 'notfound' };

      var found = [];
      (function collect(nodes) {
        nodes.forEach(function (n) {
          if (n.url) found.push({ title: n.title || '', url: n.url });
          else if (n.children) collect(n.children);
        });
      })(folder.children || []);

      return getShortcuts().then(function (current) {
        var list = current.slice();
        var added = 0;
        found.forEach(function (item) {
          var url = normalizeUrl(item.url);
          if (!url || list.length >= MAX_SHORTCUTS) return;
          var exists = list.some(function (s) { return sameAddress(s.url, url); });
          if (exists) return;
          list.push({ id: uid(), title: String(item.title).slice(0, 40), url: url });
          added++;
        });
        if (!added) return { ok: true, added: 0, total: list.length };
        return setShortcuts(list).then(function () { return { ok: true, added: added, total: list.length }; });
      });
    }).catch(function () {
      return { ok: false, reason: 'error' };
    });
  }

  /* ---------- tema ---------- */

  // Escreve o tema como variáveis CSS (--bg, --text, --accent, --sw0...).
  function applyTheme(theme, scheme, palette, el) {
    el = el || document.documentElement;
    var t = theme[scheme] || theme.dark;
    var vars = {
      '--bg': t.bg, '--surface': t.surface, '--border': t.border,
      '--text': t.text, '--muted': t.muted,
      '--accent': t.accent, '--on-accent': t.onAccent
    };
    // Cor que vai para os sites (usada na prévia da página de configuração).
    vars['--site-accent'] = theme.accent;
    vars['--site-on-accent'] = theme.onAccent;
    Object.keys(vars).forEach(function (k) { el.style.setProperty(k, vars[k]); });
    var sw = (palette && palette.swatches) || [];
    for (var i = 0; i < 6; i++) {
      var hex = sw.length ? sw[i % sw.length].hex : t.accent;
      el.style.setProperty('--sw' + i, hex);
    }
    el.style.colorScheme = scheme === 'light' ? 'light' : 'dark';
  }

  root.WPStore = {
    DEFAULT_SETTINGS: DEFAULT_SETTINGS,
    DEFAULT_THEME: DEFAULT_THEME,
    MAX_SHORTCUTS: MAX_SHORTCUTS,
    load: load,
    save: save,
    clearWallpaper: clearWallpaper,
    getShortcuts: getShortcuts,
    setShortcuts: setShortcuts,
    importSpeedDial: importSpeedDial,
    normalizeUrl: normalizeUrl,
    hostOf: hostOf,
    uid: uid,
    applyTheme: applyTheme
  };
})(self);
