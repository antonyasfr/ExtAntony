(function () {
  'use strict';

  var $ = function (id) { return document.getElementById(id); };

  var state = {
    settings: Object.assign({}, WPStore.DEFAULT_SETTINGS),
    shortcuts: []
  };

  /* ---------- relógio ---------- */

  var timeFmt = new Intl.DateTimeFormat('pt-BR', { hour: '2-digit', minute: '2-digit', hour12: false });
  var dateFmt = new Intl.DateTimeFormat('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' });

  function greetingFor(hour) {
    if (hour < 5) return 'Boa madrugada';
    if (hour < 12) return 'Bom dia';
    if (hour < 18) return 'Boa tarde';
    return 'Boa noite';
  }

  function tick() {
    var now = new Date();
    var hh = '', mm = '';
    timeFmt.formatToParts(now).forEach(function (p) {
      if (p.type === 'hour') hh = p.value;
      if (p.type === 'minute') mm = p.value;
    });
    $('hh').textContent = hh;
    $('mm').textContent = mm;
    // "sexta-feira, 6 de novembro" -> só a primeira letra em maiúscula.
    var dateText = dateFmt.format(now);
    $('date').textContent = dateText.charAt(0).toUpperCase() + dateText.slice(1);
    $('greeting').textContent = greetingFor(now.getHours());
    document.title = 'Nova aba';
  }

  /* ---------- aviso (com ação opcional, como "Desfazer") ---------- */

  var toastTimer = null;
  function toast(message, actionLabel, onAction) {
    var btn = $('toastAction');
    $('toastText').textContent = message;
    btn.hidden = !actionLabel;
    btn.onclick = null;
    if (actionLabel) {
      btn.textContent = actionLabel;
      btn.onclick = function () { $('toast').hidden = true; onAction(); };
    }
    $('toast').hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { $('toast').hidden = true; }, actionLabel ? 7000 : 4500);
  }

  /* ---------- tema e wallpaper ---------- */

  function hexToRgb(hex) {
    var n = parseInt(hex.slice(1), 16);
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }

  function render(data) {
    var hasWallpaper = !!(data.wallpaper && data.palette);
    state.settings = data.settings;
    state.shortcuts = data.shortcuts;

    WPStore.applyTheme(data.theme, 'dark', data.palette);

    document.body.classList.toggle('has-wp', hasWallpaper);
    $('bg').style.backgroundImage = hasWallpaper ? 'url("' + data.wallpaper + '")' : '';

    // Camada que escurece o wallpaper, na cor de fundo do tema.
    var c = hexToRgb(data.theme.dark.bg).join(',');
    var dim = hasWallpaper ? data.settings.dim / 100 : 0;
    $('shade').style.background =
      'linear-gradient(to bottom, rgba(' + c + ',' + (dim * 0.85).toFixed(3) + ') 0%, ' +
      'rgba(' + c + ',' + dim.toFixed(3) + ') 55%, ' +
      'rgba(' + c + ',' + Math.min(1, dim + 0.25).toFixed(3) + ') 100%)';

    // Bolinhas com as cores encontradas.
    var dots = $('dots');
    dots.replaceChildren();
    if (hasWallpaper) {
      data.palette.swatches.forEach(function (sw) {
        var dot = document.createElement('i');
        dot.style.background = sw.hex;
        dots.appendChild(dot);
      });
    }

    $('change').textContent = hasWallpaper ? 'Trocar wallpaper' : 'Escolher wallpaper';
    renderShortcuts();
  }

  /* ---------- atalhos ---------- */

  function faviconUrl(pageUrl) {
    var u = new URL(chrome.runtime.getURL('/_favicon/'));
    u.searchParams.set('pageUrl', pageUrl);
    u.searchParams.set('size', '64');
    return u.href;
  }

  function labelOf(s) {
    return s.title || WPStore.hostOf(s.url);
  }

  function miniButton(symbol, label, onClick) {
    var b = document.createElement('button');
    b.type = 'button';
    b.className = 'mini';
    b.textContent = symbol;
    b.setAttribute('aria-label', label);
    b.title = label;
    b.addEventListener('click', onClick);
    return b;
  }

  function buildTile(s) {
    var li = document.createElement('li');
    li.className = 'tile-wrap';
    li.dataset.id = s.id;
    li.draggable = true;

    var a = document.createElement('a');
    a.className = 'tile';
    a.href = s.url;
    a.draggable = false;

    var box = document.createElement('span');
    box.className = 'box';
    var ico = document.createElement('span');
    ico.className = 'ico';
    var letter = document.createElement('b');
    letter.textContent = labelOf(s).charAt(0).toUpperCase();
    ico.appendChild(letter);

    // O ícone do site aparece por cima da letra quando o Opera consegue fornecê-lo.
    var img = document.createElement('img');
    img.alt = '';
    img.width = 44;
    img.height = 44;
    img.draggable = false;
    img.addEventListener('load', function () { ico.classList.add('has-img'); });
    try { img.src = faviconUrl(s.url); } catch (e) { /* fica a letra */ }
    ico.appendChild(img);
    box.appendChild(ico);

    var name = document.createElement('span');
    name.className = 'name';
    name.textContent = labelOf(s);
    a.appendChild(box);
    a.appendChild(name);

    var tools = document.createElement('div');
    tools.className = 'tools';
    tools.appendChild(miniButton('✎', 'Editar ' + labelOf(s), function () { openEditor(s); }));
    tools.appendChild(miniButton('✕', 'Remover ' + labelOf(s), function () { removeShortcut(s); }));

    li.appendChild(a);
    li.appendChild(tools);
    return li;
  }

  function buildAddTile() {
    var li = document.createElement('li');
    li.className = 'tile-wrap add';
    var b = document.createElement('button');
    b.type = 'button';
    b.className = 'tile';
    b.id = 'addBtn';
    b.innerHTML = '<span class="box"><span class="plus" aria-hidden="true">+</span></span><span class="name">Adicionar um site</span>';
    b.addEventListener('click', function () { openEditor(null); });
    li.appendChild(b);
    return li;
  }

  function renderShortcuts() {
    $('shortcuts').hidden = state.settings.shortcuts === false;
    var ul = $('tiles');
    ul.replaceChildren();
    state.shortcuts.forEach(function (s) {
      // Só endereços http(s): protege de dados alterados por fora.
      if (s && typeof s.url === 'string' && /^https?:\/\//i.test(s.url)) ul.appendChild(buildTile(s));
    });
    ul.appendChild(buildAddTile());
    $('importRow').hidden = state.shortcuts.length > 0;
  }

  function saveShortcuts(list) {
    state.shortcuts = list;
    renderShortcuts();
    return WPStore.setShortcuts(list).catch(function () {
      toast('Não consegui salvar os atalhos. Tente de novo.');
    });
  }

  function removeShortcut(s) {
    var index = state.shortcuts.findIndex(function (x) { return x.id === s.id; });
    if (index < 0) return;
    saveShortcuts(state.shortcuts.filter(function (x) { return x.id !== s.id; }));
    toast('Atalho removido.', 'Desfazer', function () {
      var list = state.shortcuts.slice();
      list.splice(Math.min(index, list.length), 0, s);
      saveShortcuts(list);
    });
  }

  function moveShortcut(id, targetId, after) {
    var list = state.shortcuts.slice();
    var from = list.findIndex(function (s) { return s.id === id; });
    if (from < 0) return;
    var item = list.splice(from, 1)[0];
    var to = list.findIndex(function (s) { return s.id === targetId; });
    if (to < 0) return;
    list.splice(after ? to + 1 : to, 0, item);
    saveShortcuts(list);
  }

  /* ---------- janela de adicionar/editar ---------- */

  var editing = null;

  function showError(message) {
    var el = $('fError');
    el.textContent = message;
    el.hidden = !message;
  }

  function openEditor(shortcut) {
    editing = shortcut || null;
    $('editorTitle').textContent = editing ? 'Editar atalho' : 'Adicionar atalho';
    $('fUrl').value = editing ? editing.url : '';
    $('fName').value = editing ? editing.title : '';
    showError('');
    $('editor').showModal();
    $('fUrl').focus();
    $('fUrl').select();
  }

  $('editorForm').addEventListener('submit', function (e) {
    e.preventDefault();
    var url = WPStore.normalizeUrl($('fUrl').value);
    if (!url) {
      showError('Digite um endereço válido, como youtube.com.');
      $('fUrl').focus();
      return;
    }
    var title = $('fName').value.trim().slice(0, 40);
    var list = state.shortcuts.slice();

    if (editing) {
      var id = editing.id;
      list = list.map(function (s) { return s.id === id ? { id: id, title: title, url: url } : s; });
    } else {
      if (list.length >= WPStore.MAX_SHORTCUTS) {
        showError('Você chegou ao limite de ' + WPStore.MAX_SHORTCUTS + ' atalhos. Remova algum para adicionar outro.');
        return;
      }
      list.push({ id: WPStore.uid(), title: title, url: url });
    }
    saveShortcuts(list);
    $('editor').close();
  });
  $('fCancel').addEventListener('click', function () { $('editor').close(); });

  /* ---------- arrastar para mudar a ordem ---------- */

  var tiles = $('tiles');
  var dragId = null;

  function clearMarks() {
    tiles.querySelectorAll('.drop-before, .drop-after, .dragging').forEach(function (el) {
      el.classList.remove('drop-before', 'drop-after', 'dragging');
    });
  }

  function dropSide(e, li) {
    var r = li.getBoundingClientRect();
    return e.clientX > r.left + r.width / 2;
  }

  tiles.addEventListener('dragstart', function (e) {
    var li = e.target.closest && e.target.closest('li[data-id]');
    if (!li) return;
    dragId = li.dataset.id;
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', dragId);
    li.classList.add('dragging');
  });

  tiles.addEventListener('dragover', function (e) {
    if (!dragId) return;
    var li = e.target.closest('li[data-id]');
    if (!li || li.dataset.id === dragId) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    tiles.querySelectorAll('.drop-before, .drop-after').forEach(function (el) {
      el.classList.remove('drop-before', 'drop-after');
    });
    li.classList.add(dropSide(e, li) ? 'drop-after' : 'drop-before');
  });

  tiles.addEventListener('drop', function (e) {
    if (!dragId) return;
    var li = e.target.closest('li[data-id]');
    if (!li || li.dataset.id === dragId) return;
    e.preventDefault();
    var id = dragId;
    dragId = null;
    moveShortcut(id, li.dataset.id, dropSide(e, li));
  });

  tiles.addEventListener('dragend', function () {
    dragId = null;
    clearMarks();
  });

  /* ---------- importar da Discagem Rápida do Opera ---------- */

  $('importBtn').addEventListener('click', function () {
    WPStore.importSpeedDial().then(function (r) {
      if (r.ok && r.added) toast('Trouxe ' + r.added + (r.added === 1 ? ' atalho' : ' atalhos') + ' da Discagem Rápida.');
      else if (r.ok) toast('Não há atalhos novos para trazer.');
      else if (r.reason === 'notfound') toast('Não encontrei a Discagem Rápida nos favoritos do Opera. Use o botão + para adicionar seus atalhos.');
      else toast('Não consegui ler os favoritos do Opera.');
    });
  });

  /* ---------- busca ---------- */

  // Endereço de site (e não uma pesquisa): começa com http(s)://, www., ou é um domínio conhecido.
  function isAddress(text) {
    if (/\s/.test(text)) return false;
    return /^https?:\/\/\S+$/i.test(text) ||
      /^www\.\S+\.\S+$/i.test(text) ||
      /^localhost(:\d+)?(\/\S*)?$/i.test(text) ||
      /^[a-z0-9-]+(\.[a-z0-9-]+)*\.(com|org|net|io|dev|app|gov|edu|co|me|tv|ai|info|xyz|br)(:\d+)?(\/\S*)?$/i.test(text);
  }

  $('search').addEventListener('submit', function (e) {
    e.preventDefault();
    var text = $('q').value.trim();
    if (!text) return;

    if (isAddress(text)) {
      location.href = /^https?:\/\//i.test(text) ? text : 'https://' + text;
      return;
    }
    try {
      if (chrome.search && chrome.search.query) {
        chrome.search.query({ text: text, disposition: 'CURRENT_TAB' });
        return;
      }
    } catch (err) { /* cai no buscador padrão abaixo */ }
    location.href = 'https://www.google.com/search?q=' + encodeURIComponent(text);
  });

  // Atalho: "/" leva o cursor para a busca (menos quando já se está digitando em algum campo).
  document.addEventListener('keydown', function (e) {
    var tag = document.activeElement && document.activeElement.tagName;
    if (e.key === '/' && !/^(INPUT|TEXTAREA|SELECT)$/.test(tag) && !e.ctrlKey && !e.metaKey && !e.altKey) {
      e.preventDefault();
      $('q').focus();
    }
  });

  $('change').addEventListener('click', function () {
    chrome.runtime.openOptionsPage();
  });

  /* ---------- mudanças feitas em outras abas ---------- */

  chrome.storage.onChanged.addListener(function (changes, area) {
    if (area !== 'local') return;
    if (changes.wallpaper || changes.palette || changes.theme || changes.settings) {
      WPStore.load().then(render);
      return;
    }
    if (changes.shortcuts) {
      var next = changes.shortcuts.newValue || [];
      if (JSON.stringify(next) !== JSON.stringify(state.shortcuts)) {
        state.shortcuts = next;
        renderShortcuts();
      }
    }
  });

  tick();
  setInterval(tick, 1000);
  WPStore.load().then(render);

  // Como a aba abre pela extensão, o cursor não vai para a barra de endereço sozinho.
  // Deixar a busca pronta para digitar faz o papel dela.
  $('q').focus();
})();
