/*
 * palette.js — extrai as cores de uma imagem e monta o tema.
 * Sem dependências. Funciona no navegador (window.WPPalette) e no Node (para testes).
 */
(function (root) {
  'use strict';

  var clamp = function (v, a, b) { return Math.min(b, Math.max(a, v)); };

  /* ---------- conversões de cor ---------- */

  function srgbToLinear(c) {
    c /= 255;
    return c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
  }

  // OKLab: distância entre cores parecida com a que o olho percebe.
  function rgbToOklab(r, g, b) {
    var lr = srgbToLinear(r), lg = srgbToLinear(g), lb = srgbToLinear(b);
    var l = Math.cbrt(0.4122214708 * lr + 0.5363325363 * lg + 0.0514459929 * lb);
    var m = Math.cbrt(0.2119034982 * lr + 0.6806995451 * lg + 0.1073969566 * lb);
    var s = Math.cbrt(0.0883024619 * lr + 0.2817188376 * lg + 0.6299787005 * lb);
    return [
      0.2104542553 * l + 0.7936177850 * m - 0.0040720468 * s,
      1.9779984951 * l - 2.4285922050 * m + 0.4505937099 * s,
      0.0259040371 * l + 0.7827717662 * m - 0.8086757660 * s
    ];
  }

  function rgbToHsl(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    var max = Math.max(r, g, b), min = Math.min(r, g, b);
    var l = (max + min) / 2, h = 0, s = 0;
    var d = max - min;
    if (d > 0) {
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      if (max === r) h = (g - b) / d + (g < b ? 6 : 0);
      else if (max === g) h = (b - r) / d + 2;
      else h = (r - g) / d + 4;
      h *= 60;
    }
    return [h, s, l];
  }

  function hslToRgb(h, s, l) {
    h = ((h % 360) + 360) % 360;
    s = clamp(s, 0, 1);
    l = clamp(l, 0, 1);
    var c = (1 - Math.abs(2 * l - 1)) * s;
    var x = c * (1 - Math.abs(((h / 60) % 2) - 1));
    var m = l - c / 2;
    var r = 0, g = 0, b = 0;
    if (h < 60) { r = c; g = x; }
    else if (h < 120) { r = x; g = c; }
    else if (h < 180) { g = c; b = x; }
    else if (h < 240) { g = x; b = c; }
    else if (h < 300) { r = x; b = c; }
    else { r = c; b = x; }
    return [
      Math.round((r + m) * 255),
      Math.round((g + m) * 255),
      Math.round((b + m) * 255)
    ];
  }

  function toHex(rgb) {
    return '#' + rgb.map(function (v) {
      var h = clamp(Math.round(v), 0, 255).toString(16);
      return h.length === 1 ? '0' + h : h;
    }).join('');
  }

  function fromHex(hex) {
    var n = parseInt(hex.slice(1), 16);
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }

  function luminance(rgb) {
    return 0.2126 * srgbToLinear(rgb[0]) + 0.7152 * srgbToLinear(rgb[1]) + 0.0722 * srgbToLinear(rgb[2]);
  }

  // Razão de contraste do WCAG (1 a 21).
  function contrast(a, b) {
    var la = luminance(a), lb = luminance(b);
    var hi = Math.max(la, lb), lo = Math.min(la, lb);
    return (hi + 0.05) / (lo + 0.05);
  }

  function readableOn(rgb) {
    return contrast(rgb, [255, 255, 255]) >= contrast(rgb, [0, 0, 0]) ? '#ffffff' : '#000000';
  }

  function dist2(a, b) {
    var dl = a[0] - b[0], da = a[1] - b[1], db = a[2] - b[2];
    return dl * dl + da * da + db * db;
  }

  /* ---------- extração ---------- */

  /**
   * data: Uint8ClampedArray RGBA (imagem já reduzida, algo como 96 px de lado maior).
   * Retorna { swatches, accentIndex, isDark, avgL } ou null se a imagem estiver vazia.
   */
  function extract(data, options) {
    var K = (options && options.k) || 8;

    // 1. Histograma com 4 bits por canal.
    var buckets = new Map();
    var total = 0;
    for (var i = 0; i < data.length; i += 4) {
      if (data[i + 3] < 125) continue;
      var r = data[i], g = data[i + 1], b = data[i + 2];
      var key = ((r >> 4) << 8) | ((g >> 4) << 4) | (b >> 4);
      var e = buckets.get(key);
      if (!e) { e = { n: 0, r: 0, g: 0, b: 0 }; buckets.set(key, e); }
      e.n++; e.r += r; e.g += g; e.b += b;
      total++;
    }
    if (!total) return null;

    var pts = [];
    buckets.forEach(function (e) {
      var pr = e.r / e.n, pg = e.g / e.n, pb = e.b / e.n;
      pts.push({ n: e.n, rgb: [pr, pg, pb], lab: rgbToOklab(pr, pg, pb) });
    });

    // 2. k-means em OKLab, com sementes espalhadas (mais distantes primeiro).
    var k = Math.min(K, pts.length);
    var heaviest = pts[0];
    pts.forEach(function (p) { if (p.n > heaviest.n) heaviest = p; });
    var centers = [heaviest.lab.slice()];
    var minD = pts.map(function (p) { return dist2(p.lab, centers[0]); });
    while (centers.length < k) {
      var best = -1, bestV = 0;
      for (var a = 0; a < pts.length; a++) {
        var v = minD[a] * Math.sqrt(pts[a].n);
        if (v > bestV) { bestV = v; best = a; }
      }
      if (best < 0) break;
      var seed = pts[best].lab.slice();
      centers.push(seed);
      for (var c0 = 0; c0 < pts.length; c0++) {
        var d0 = dist2(pts[c0].lab, seed);
        if (d0 < minD[c0]) minD[c0] = d0;
      }
    }

    var assign = new Array(pts.length).fill(-1);
    for (var it = 0; it < 14; it++) {
      var sums = centers.map(function () { return { n: 0, l: 0, a: 0, b: 0 }; });
      var changed = false;
      for (var p = 0; p < pts.length; p++) {
        var bi = 0, bd = Infinity;
        for (var c = 0; c < centers.length; c++) {
          var d = dist2(pts[p].lab, centers[c]);
          if (d < bd) { bd = d; bi = c; }
        }
        if (assign[p] !== bi) { assign[p] = bi; changed = true; }
        var s = sums[bi], w = pts[p].n;
        s.n += w; s.l += pts[p].lab[0] * w; s.a += pts[p].lab[1] * w; s.b += pts[p].lab[2] * w;
      }
      for (var cc = 0; cc < centers.length; cc++) {
        if (sums[cc].n) centers[cc] = [sums[cc].l / sums[cc].n, sums[cc].a / sums[cc].n, sums[cc].b / sums[cc].n];
      }
      if (!changed) break;
    }

    // 3. Monta os grupos.
    var clusters = centers.map(function () { return { n: 0, r: 0, g: 0, b: 0 }; });
    for (var q = 0; q < pts.length; q++) {
      var cl = clusters[assign[q]], wq = pts[q].n;
      cl.n += wq; cl.r += pts[q].rgb[0] * wq; cl.g += pts[q].rgb[1] * wq; cl.b += pts[q].rgb[2] * wq;
    }
    clusters = clusters.filter(function (x) { return x.n > 0; }).map(function (x) {
      var rgb = [x.r / x.n, x.g / x.n, x.b / x.n];
      return { n: x.n, rgb: rgb, lab: rgbToOklab(rgb[0], rgb[1], rgb[2]) };
    });

    // 4. Junta grupos quase iguais.
    var merged = true;
    while (merged && clusters.length > 1) {
      merged = false;
      outer:
      for (var x = 0; x < clusters.length; x++) {
        for (var y = x + 1; y < clusters.length; y++) {
          if (dist2(clusters[x].lab, clusters[y].lab) < 0.06 * 0.06) {
            var A = clusters[x], B = clusters[y], n = A.n + B.n;
            var rgbM = [0, 1, 2].map(function (i2) { return (A.rgb[i2] * A.n + B.rgb[i2] * B.n) / n; });
            clusters[x] = { n: n, rgb: rgbM, lab: rgbToOklab(rgbM[0], rgbM[1], rgbM[2]) };
            clusters.splice(y, 1);
            merged = true;
            break outer;
          }
        }
      }
    }

    // 5. Números de cada cor.
    var avgL = 0;
    var swatches = clusters.map(function (cl) {
      var rgb = cl.rgb.map(Math.round);
      var hsl = rgbToHsl(rgb[0], rgb[1], rgb[2]);
      var share = cl.n / total;
      avgL += share * cl.lab[0];
      return {
        hex: toHex(rgb),
        share: Math.round(share * 10000) / 10000,
        h: Math.round(hsl[0]),
        s: Math.round(hsl[1] * 1000) / 1000,
        l: Math.round(hsl[2] * 1000) / 1000,
        L: Math.round(cl.lab[0] * 1000) / 1000,
        C: Math.round(Math.sqrt(cl.lab[1] * cl.lab[1] + cl.lab[2] * cl.lab[2]) * 1000) / 1000
      };
    });
    swatches.sort(function (a, b) { return b.share - a.share; });
    swatches = swatches.slice(0, 6);

    // 6. Escolhe a cor de destaque: viva, visível e com presença na imagem.
    var accentIndex = 0, bestScore = 0;
    swatches.forEach(function (sw, idx) {
      if (sw.share < 0.004) return;
      var lightnessFit = Math.max(0.2, 1 - 1.6 * Math.abs(sw.L - 0.68));
      var score = sw.C * Math.pow(sw.share, 0.35) * lightnessFit;
      if (score > bestScore) { bestScore = score; accentIndex = idx; }
    });
    if (swatches[accentIndex].C < 0.03) accentIndex = 0; // imagem sem cor: usa a dominante

    return {
      swatches: swatches,
      accentIndex: accentIndex,
      avgL: Math.round(avgL * 1000) / 1000,
      isDark: avgL < 0.6
    };
  }

  /* ---------- tema ---------- */

  // Ajusta a luminosidade até a cor ter contraste mínimo com o fundo.
  function ensureContrast(hsl, bgRgb, min, lighten) {
    var h = hsl[0], s = hsl[1], l = hsl[2];
    var rgb = hslToRgb(h, s, l);
    var guard = 0;
    while (contrast(rgb, bgRgb) < min && guard++ < 60) {
      l = clamp(l + (lighten ? 0.015 : -0.015), 0, 1);
      rgb = hslToRgb(h, s, l);
    }
    return rgb;
  }

  function buildScheme(hue, sat, accentHsl, isDarkScheme) {
    var bg, surface, border, text, muted;
    if (isDarkScheme) {
      bg = hslToRgb(hue, sat * 0.55, 0.085);
      surface = hslToRgb(hue, sat * 0.5, 0.135);
      border = hslToRgb(hue, sat * 0.4, 0.22);
      text = hslToRgb(hue, sat * 0.25, 0.95);
      muted = hslToRgb(hue, sat * 0.2, 0.72);
    } else {
      bg = hslToRgb(hue, sat * 0.6, 0.955);
      surface = hslToRgb(hue, sat * 0.4, 0.99);
      border = hslToRgb(hue, sat * 0.35, 0.86);
      text = hslToRgb(hue, sat * 0.5, 0.11);
      muted = hslToRgb(hue, sat * 0.2, 0.38);
    }
    var accent = ensureContrast(accentHsl, bg, 3, isDarkScheme);
    return {
      bg: toHex(bg),
      surface: toHex(surface),
      border: toHex(border),
      text: toHex(text),
      muted: toHex(muted),
      accent: toHex(accent),
      onAccent: readableOn(accent)
    };
  }

  /**
   * palette: resultado de extract(). choice: 'auto' ou índice da cor escolhida.
   * Retorna o tema que as páginas e o script de conteúdo usam.
   */
  function buildTheme(palette, choice) {
    var sw = palette.swatches;
    var idx = (choice === 'auto' || sw[choice] == null) ? palette.accentIndex : choice;
    var chosen = sw[idx];
    var hsl = rgbToHsl.apply(null, fromHex(chosen.hex));

    // Cor de destaque para os sites: mantém o tom, evita cores escuras demais ou lavadas.
    var siteHsl = [hsl[0], clamp(hsl[1], 0, 0.95), clamp(hsl[2], 0.4, 0.66)];
    var siteRgb = hslToRgb(siteHsl[0], siteHsl[1], siteHsl[2]);

    // Tom dos fundos: a cor mais presente que tenha matiz de verdade.
    var tint = sw.filter(function (x) { return x.C > 0.03; })
                 .sort(function (a, b) { return b.share - a.share; })[0] || chosen;
    var tintSat = clamp(tint.s, 0, 0.6);

    return {
      accent: toHex(siteRgb),
      onAccent: readableOn(siteRgb),
      scheme: palette.isDark ? 'dark' : 'light',
      dark: buildScheme(tint.h, tintSat, siteHsl, true),
      light: buildScheme(tint.h, tintSat, siteHsl, false)
    };
  }

  /* ---------- ajudantes do navegador ---------- */

  // Reduz a imagem e devolve os pixels para extract().
  function samplePixels(bitmap, side) {
    side = side || 96;
    var scale = Math.min(1, side / Math.max(bitmap.width, bitmap.height));
    var w = Math.max(1, Math.round(bitmap.width * scale));
    var h = Math.max(1, Math.round(bitmap.height * scale));
    var canvas = document.createElement('canvas');
    canvas.width = w; canvas.height = h;
    var ctx = canvas.getContext('2d', { willReadFrequently: true });
    ctx.drawImage(bitmap, 0, 0, w, h);
    return ctx.getImageData(0, 0, w, h).data;
  }

  // Reduz a imagem (até 1920 px) e devolve como JPEG em data URL, para guardar na extensão.
  function encodeImage(bitmap, maxSide, quality) {
    maxSide = maxSide || 1920;
    var q = quality || 0.85;
    var scale = Math.min(1, maxSide / Math.max(bitmap.width, bitmap.height));
    var w = Math.max(1, Math.round(bitmap.width * scale));
    var h = Math.max(1, Math.round(bitmap.height * scale));
    var canvas = document.createElement('canvas');
    canvas.width = w; canvas.height = h;
    var ctx = canvas.getContext('2d');
    ctx.fillStyle = '#000';
    ctx.fillRect(0, 0, w, h);
    ctx.drawImage(bitmap, 0, 0, w, h);
    var url = canvas.toDataURL('image/jpeg', q);
    while (url.length > 4000000 && q > 0.5) {
      q -= 0.1;
      url = canvas.toDataURL('image/jpeg', q);
    }
    return url;
  }

  var api = {
    extract: extract,
    buildTheme: buildTheme,
    samplePixels: samplePixels,
    encodeImage: encodeImage,
    contrast: contrast,
    fromHex: fromHex,
    toHex: toHex,
    readableOn: readableOn
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.WPPalette = api;
})(typeof self !== 'undefined' ? self : this);
