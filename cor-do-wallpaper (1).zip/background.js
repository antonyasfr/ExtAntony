// Clicar no ícone da extensão abre a página de configuração.
chrome.action.onClicked.addListener(() => {
  chrome.runtime.openOptionsPage();
});

// Na primeira instalação, já abre a configuração para escolher o wallpaper.
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    chrome.runtime.openOptionsPage();
  }
});

/*
 * O Opera não deixa extensões trocarem a página inicial dele (o chrome_url_overrides é ignorado).
 * Contorno: quando uma aba abre na página inicial do Opera, abrimos a nova aba da extensão no
 * mesmo lugar e fechamos a original. A aba nova não traz a página do Opera no histórico,
 * então o botão "voltar" não fica preso.
 */
const OPERA_START = /^(chrome|opera):\/\/(startpage|newtab)/i;
const OUR_PAGE = chrome.runtime.getURL('newtab.html');
const handled = new Set();

// Só assume a nova aba quando já existe um wallpaper (o tema só existe com wallpaper)
// e a opção está ligada.
async function shouldTakeOver() {
  const data = await chrome.storage.local.get(['settings', 'theme']);
  const settings = data.settings || {};
  return !!data.theme && settings.newtab !== false;
}

async function takeOver(tab) {
  if (!tab || tab.id == null || handled.has(tab.id)) return;
  const url = tab.pendingUrl || tab.url || '';
  if (!OPERA_START.test(url)) return;

  handled.add(tab.id);
  try {
    if (!(await shouldTakeOver())) return;
    await chrome.tabs.create({
      windowId: tab.windowId,
      index: tab.index,
      active: tab.active,
      url: OUR_PAGE
    });
    await chrome.tabs.remove(tab.id);
  } catch (err) {
    // Se algo falhar, o Opera continua mostrando a página dele.
  }
}

chrome.tabs.onCreated.addListener(takeOver);
chrome.tabs.onUpdated.addListener((tabId, change, tab) => {
  if (change.url || change.status === 'loading') takeOver(tab);
});
chrome.tabs.onRemoved.addListener((tabId) => handled.delete(tabId));
