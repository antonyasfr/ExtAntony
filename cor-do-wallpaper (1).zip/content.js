/*
 * content.js — aplica as cores do wallpaper nos sites.
 *  1. Cor de destaque (caixas de seleção, seleção de texto, cursor). Só CSS comum: se o site
 *     define a própria cor, a dele vale.
 *  2. Camada de cor sobre a página ("Tingir as páginas"), só no Google ou em todos os sites.
 *     A camada usa mistura "color": muda o tom, mantém o brilho, então o texto continua legível.
 * Não lê o conteúdo das páginas e não envia nada para fora.
 */
(function () {
  'use strict';

  if (document.contentType && document.contentType.indexOf('html') === -1) return;
  if (!chrome || !chrome.storage || !chrome.storage.local) return;

  var STYLE_ID = '__cor-do-wallpaper__';
  var TINT_ID = '__cor-do-wallpaper-tint__';
  var DEFAULTS = { sites: true, scrollbars: false, tint: 'google', tintAmount: 20 };

  // Busca do Google (google.com, www.google.com.br, google.co.uk...). Gmail, Docs etc. ficam de fora.
  var IS_GOOGLE = /^(?:www\.)?google\.(?:com?(?:\.[a-z]{2})?|[a-z]{2})$/i.test(location.hostname);

  var state = { settings: Object.assign({}, DEFAULTS), theme: null };

  function tintEnabled() {
    var s = state.settings;
    if (!state.theme || !(s.tintAmount > 0)) return false;
    return s.tint === 'all' || (s.tint === 'google' && IS_GOOGLE);
  }

  function buildCss() {
    var s = state.settings;
    var t = state.theme;
    var css = '';
    if (s.sites) {
      var a = t.accent;
      css +=
        ':root{accent-color:' + a + ';}' +
        '::selection{background:' + a + ';color:' + t.onAccent + ';}' +
        'input,textarea,[contenteditable="true"],[contenteditable=""]{caret-color:' + a + ';}' +
        ':focus-visible{outline-color:' + a + ';}';
      if (s.scrollbars) css += 'html{scrollbar-color:' + a + ' transparent;}';
    }
    if (tintEnabled()) {
      css += '@media print{#' + TINT_ID + '{display:none!important;}}';
    }
    return css;
  }

  function applyStyle() {
    var existing = document.getElementById(STYLE_ID);
    var css = state.theme ? buildCss() : '';
    if (!css) {
      if (existing) existing.remove();
      return;
    }
    if (existing) {
      if (existing.textContent !== css) existing.textContent = css;
      return;
    }
    var el = document.createElement('style');
    el.id = STYLE_ID;
    el.textContent = css;
    (document.head || document.documentElement).appendChild(el);
  }

  function applyTint() {
    var el = document.getElementById(TINT_ID);
    if (!tintEnabled()) {
      if (el) el.remove();
      return;
    }
    if (!el) {
      el = document.createElement('div');
      el.id = TINT_ID;
      el.setAttribute('aria-hidden', 'true');
      var fixed = {
        position: 'fixed', top: '0', left: '0', right: '0', bottom: '0',
        width: 'auto', height: 'auto', margin: '0', padding: '0', border: '0',
        'pointer-events': 'none', 'z-index': '2147483647', 'mix-blend-mode': 'color'
      };
      Object.keys(fixed).forEach(function (k) { el.style.setProperty(k, fixed[k], 'important'); });
      document.documentElement.appendChild(el);
    }
    el.style.setProperty('background', state.theme.accent, 'important');
    el.style.setProperty('opacity', String(state.settings.tintAmount / 100), 'important');
  }

  function apply() {
    applyStyle();
    applyTint();
  }

  function withDefaults(saved) {
    return Object.assign({}, DEFAULTS, saved || {});
  }

  chrome.storage.local.get(['settings', 'theme']).then(function (d) {
    state.settings = withDefaults(d.settings);
    state.theme = d.theme || null;
    apply();
  });

  chrome.storage.onChanged.addListener(function (changes, area) {
    if (area !== 'local') return;
    if (changes.settings) state.settings = withDefaults(changes.settings.newValue);
    if (changes.theme) state.theme = changes.theme.newValue || null;
    if (changes.settings || changes.theme) apply();
  });
})();
